
<?php

echo "det funkar nu";

?>
