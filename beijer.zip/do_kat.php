
<?php

include('connect.inc');
include('ftg.inc');

$PID  = $_GET['pid'];
$KID  = $_GET['kat'];
$PULS = $_GET['puls'];

$TITLE = "Fr&aring;geformul&auml;r " . $KATNAMES[$KID];
include('wrapper_before.php');

include('kat_names.inc');

$KNAM = $KATNAMES[ "" . $KID ];

$BODY_STUFF = "";
$SCRIPT_STUFF = "";

$BODY_STUFF .= '<form action="post_query.php" id="query" method="get" >' ;
$BODY_STUFF .= '<div id="idtag" style="display: none;">' ;
$BODY_STUFF .= '<input type="text" name="pid"  value="' . $PID  . '">' ;
$BODY_STUFF .= '<input type="text" name="kat"  value="' . $KID  . '">' ;
$BODY_STUFF .= '<input type="text" name="prim" value="' . 1     . '">' ;
$BODY_STUFF .= '<input type="text" name="puls" value="' . $PULS . '">' ;
$BODY_STUFF .= '</div>' . "\n";
$BODY_STUFF .= "<center><table style='width:70%'>\n";
$BODY_STUFF .= "<tr><td colspan=3> <center> <h1> " . $KNAM . "</h1></center></td></tr>\n";

$EDNUM = 0;
$EDREM = 0;
$EDQID = 0;

$NUM = 0;

$query_post_q = "SELECT * FROM " . $MainDB . "_QUERY WHERE query_prim='1' AND query_sec='1' AND query_sns>=0" ;
$result_q = mysqli_query($emperator, $query_post_q);
while ($row_q = mysqli_fetch_array($result_q))
{
	$NUM += 1;
	$BODY_STUFF .= "<tr><td>";
	$BODY_STUFF .= "<!--br-->" . $NUM . "<br><!--br-->";
	$BODY_STUFF .= "</td><td>";
	$BODY_STUFF .= $row_q['query_title'];
	$BODY_STUFF .= "</td><td>";
	$QTXT = $row_q['query_text'];
	$BODY_STUFF .= str_replace('%kat%', $KNAM, $QTXT);
	$BODY_STUFF .= "</td><td>" ;

	$QID = $row_q['query_id'];
	$KND = $row_q['query_csa'];

	$SNS = $row_q['query_sns'];
	if ($SNS != 0)
	{
		$EDNUM += 1;
		$EDREM = $SNS;
		$EDQID = $QID;
		$CH = "on_sel_ch_" . $EDNUM . "()";
	} else {
		$CH = "on_sel_ch()";
	}

	if (($SNS == 0) && ($EDREM != 0))
	{
		$BODY_STUFF .= '<div id="onoff_' . $EDNUM . '"> <br> </div>' . "\n";

		$SCRIPT_STUFF .= 'function on_sel_ch_' . $EDNUM . "()\n{\n";
		$SCRIPT_STUFF .= '  oo = document.getElementById("' . $EDQID . '");' . "\n";
		$SCRIPT_STUFF .= "  if (oo.options[oo.selectedIndex].value > 0) do_enable_" . $EDNUM . "(); else do_disable_" . $EDNUM . "();\n";
		$SCRIPT_STUFF .= "  on_sel_ch();\n}\n";
		$SCRIPT_STUFF .= 'function do_disable_' . $EDNUM . "()\n{\n";
		$SCRIPT_STUFF .= "  min_ch -= 1;\n";
		$SCRIPT_STUFF .= '  oo = document.getElementById("onoff_' . $EDNUM . '");' . "\n";
		$SCRIPT_STUFF .= "  oo.innerHTML = '<br>';\n";
		$SCRIPT_STUFF .= "}\n";
		$SCRIPT_STUFF .= 'function do_enable_' . $EDNUM . "()\n{\n";
		//$SCRIPT_STUFF .= "  min_ch += 1;\n";
		$SCRIPT_STUFF .= '  oo = document.getElementById("onoff_' . $EDNUM . '");' . "\n";
		$SCRIPT_STUFF .= "  oo.innerHTML = '";
	}

	$TMP = "";

	if ($KND == 'bool')
	{
		$TMP .= '<select onchange="' . $CH . '" form="query" id="' . $QID . '" name="' . $QID . '">' ;
		$TMP .= '<option disabled selected value>' .  ' &nbsp; ----- v&auml;lj ----- ' ;
		$TMP .= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		$TMP .= '</option>' ;
		$TMP .= '<option value="1"> &nbsp; ' . "Ja" . ' </option>' ;
		$TMP .= '<option value="0"> &nbsp; ' . "Nej" . ' </option>' ;
		$TMP .= '</select>' ;
	}
	else if ($KND == 'num')
	{
		$TMP .= '<input onchange="' . $CH . '" type="number" name="' . $QID . '">' ;
	}
	else
	{
		$TMP .= '<select onchange="' . $CH . '" form="query" id="' . $QID . '" name="' . $QID . '">' ;
		$TMP .= '<option disabled selected value>' .  ' &nbsp; ----- v&auml;lj ----- ' ;
		$TMP .= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		$TMP .= '</option>' ;
		$nn = 1;
		$arr = explode(",", $KND);
		foreach ($arr as $value)
		{
			$TMP .= '<option value="' . $nn . '"> &nbsp; ' . $value . ' </option>' ;
			$nn += 1;
		}
		$TMP .= '</select>' ;
	}

	if (($SNS == 0) && ($EDREM != 0))
	{
		$SCRIPT_STUFF .= $TMP;
		$SCRIPT_STUFF .=  "';";
		$SCRIPT_STUFF .=  "\n}\n";
		$EDREM -= 1;
	} else {
		$BODY_STUFF .= $TMP;
	}

	$BODY_STUFF .= "\n</td></tr>\n";

}

echo <<<EOT

<script>

var ch_cnt = 0;
var min_ch = $NUM;

function on_sel_ch(sender)
{
	ch_cnt += 1;
	tsb = document.getElementById("thesubmitbutton");
	if (ch_cnt < min_ch)
	{
		tsb.innerHTML = "<button type='button' onclick='alert(\"svara p&aring; alla fr&aring;gorna\")'> Klar </button>";
	} else {
		tsb.innerHTML = "<input type='submit' value='Klar'         >";
	}
}

EOT;

echo $SCRIPT_STUFF . "\n</script>\n";

echo $BODY_STUFF . "\n";

echo "<tr> <td></td> <td></td> <td></td> <td> <div id='thesubmitbutton'> <button type='button' onclick='alert(\"svara p&aring; alla fr&aring;gorna\")'> Klar </button> </div> </td> </tr>" ;

echo "</table></center>";

echo "</form>";

mysqli_close($emperator);

include('wrapper_after.php');

?>


