
<?php

$TITLE="ElitTeam";

include('wrapper_before.php');

include('connect.inc');
include('ftg.inc');

include('kat_names.inc');

echo "<center><table style='width:70%'><tr><td>\n";

echo "<br><br>\n";

// --------------------------------------------------------

echo "<form  action='d_eval.php'>";

echo "<table class='pretty'>\n";

$PID = $_GET['pid'];

include('pqs.inc');

echo "<caption> Utv&auml;rdering " . $pqs['name'] . " </caption>\n";
echo "<tr> <th> Kategori </th> <th> Fr&aring;gor </th> <th> Niv&aring; (1-7) </th> <th> Utv&auml;rdering (1-7) </th> </tr> \n";

$PID = $_GET['pid'];

echo "<input type='text' name='pid' hidden value='" . $PID . "'> \n";
echo "<input type='text' name='puls' hidden value='" . 1 . "'> \n";

include('pqs.inc');

function adjust($NUM)
{
	$RES = (int) round($NUM, 0);
	if ($RES < 1)
		$RES = 1;
	if ($RES > 7)
		$RES = 7;
	return $RES;
}

foreach ($pqs['kats'] as $kats)
{
	echo "<tr>";
	echo "<td>" . $kats['name'] . "</td>";
	$sum = 0;
	foreach ($kats['querys'] as $querys)
	{
		$sum += $querys['answer'] * $querys['weight'];
	}

	echo "<td>" . $sum . " av " . $kats['max'] . "</td>";

	$sum = $sum * 7.5 / $kats['max'];

	$sum = adjust($sum);

	echo "<td>" . $sum . "</td>";

	echo "<input type='text' name='self_" . $kats['major'] . "_" . $kats['kat'] . "' hidden value='" . $sum . "'> \n";

	echo "<td>&nbsp;&nbsp;";
	for ($II = 1; $II <= 7; ++$II)
	{
		echo "<input type='radio' name='eval_" . $kats['major'] . "_" . $kats['kat'] . "' value='" . $II . "' >";
		echo " <B>" . $II . "</B> &nbsp; \n";
	}

	//echo "<td>" ;
	//echo "<input type='text' name='eval_" . $kats['major'] . "_" . $kats['kat'] . "' value='" . $sum . "'> \n";
	echo "</td></tr>\n";
}


echo "</table>\n";

echo "<div align='right'>";
echo "<br><input type='submit' value='Submit'>";
echo "</div>";

// --------------------------------------------------------


echo "</td></tr></table></center>\n";


?>

