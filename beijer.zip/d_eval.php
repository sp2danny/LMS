
<?php

$TITLE="ElitTeam";

include('wrapper_before.php');

include('connect.inc');
include('ftg.inc');

include('kat_names.inc');

echo "<center><table style='width:70%'><tr><td>\n";

echo "<br><br>\n";

// --------------------------------------------------------

$PID = $_GET['pid'];

include('pqs.inc');

foreach ($pqs['kats'] as $kats)
{
	$MAJ = $kats['major'];
	$KAT = $kats['kat'];
	$SELF = "self_" . $MAJ . "_" . $KAT;
	$EVAL = "eval_" . $MAJ . "_" . $KAT;

	$sval = $_GET[$SELF];
	$eval = $_GET[$EVAL];

	echo "about to save "
		. $PID . ", "
		. $_GET['puls'] . ", "
		. $MAJ . ", "
		. $KAT . ", "
		. $sval . ", "
		. $eval . "<br>\n";


	$query_ans = "INSERT INTO " . $MainDB . "_UTV ";
	$query_ans .= "(utv_pers,utv_puls,utv_ftg,utv_prim,utv_kat,utv_self,utv_utv)";
	$query_ans .= " VALUES ";
	$query_ans .= "('" . $PID . "','" . $_GET['puls'] . "','" . $FTG . "','" . $MAJ . "','" . $KAT . "','" . $sval . "','" . $eval . "')";
	echo "query<br>" . $query_ans . "<br>\n";

	$result_ans = mysqli_query( $emperator, $query_ans );
	if (!$result_ans)
	{
		echo "<br>an error occured in insert ans<br>\n";
		$ERR = true;
	}

	if (!$ERR)
	{
		$query_pku = "UPDATE " . $MainDB . "_PKAT ";
		$query_pku .= "SET pkat_utvdone=" . $_GET['puls'] . " ";
		$query_pku .= "WHERE pkat_pers=" . $PID . " AND pkat_major=" . $MAJ . " AND pkat_kat=" . $KAT;
		echo "query 2<br>" . $query_pku . "<br>\n";
		$result_pku = mysqli_query( $emperator, $query_pku );
		if (!$result_pku)
		{
			echo "<br>update pkat failed<br>\n";
			echo "<br>query was : " . $query_pku . "<br>\n";
			$ERR = true;
		} else {
			//echo "<br>all ok<br>\n";
		}
	}

	$GOTO = "b_eval.php?pid=" . $PID ;
	$GOTO .= "&puls=" . $_GET['puls'];

	if (!$ERR)
	{

		echo <<<EOT
	
		<meta http-equiv="refresh" content="1; url=$GOTO">
			 
		<script>
			window.location.href = "$GOTO";
		</script>
EOT;

	}

	echo "<br><br><button onclick=\"window.location.assign('$GOTO')\" > Tillbaka </button><br>\n";

}


// --------------------------------------------------------

echo "</td></tr></table></center>\n";



