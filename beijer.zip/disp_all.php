
<?php

$TITLE="ElitTeam";

include('wrapper_before.php');

include('connect.inc');
include('ftg.inc');

$FNUM = $FTG;

$PID = $_GET['pid'];

$query_0 = "SELECT * FROM ET_PERS WHERE pers_id=" . $PID;
$result_0 = mysqli_query($emperator,$query_0);
if($result_0) if( $row_0 = mysqli_fetch_array($result_0) )
{
	$FNUM = $row_0['pers_ftg'];
}

if( isset($_GET['puls']) )
{
	$PULS = $_GET['puls'];
} else {
	$query_1 = "SELECT * FROM " . $MainDB . "_PULS WHERE puls_ftg=" . $FNUM;
	$result_1 = mysqli_query($emperator,$query_1);
	if($result_1)
	{
		$PULS = 1;
		while( $row_1 = mysqli_fetch_array($result_1) )
		{
			if( $row_1['puls_id'] > $PULS )
				$PULS = $row_1['puls_id'];
		}
	}
}

$mydata = array();

$query_2 = "SELECT * FROM " . $MainDB . "_PERS WHERE pers_ftg=" . $FNUM;
$result_2 = mysqli_query($emperator,$query_2);
if($result_2) while( $row_2 = mysqli_fetch_array($result_2) )
{
  $PERS = $row_2['pers_id'];
  $mydata[ $PERS ] = new StdClass();
  $mydata[ $PERS ]->pid = $PERS;
  $mydata[ $PERS ]->name = htmlentities( $row_2['pers_fname'] . " " . $row_2['pers_ename'], ENT_COMPAT | ENT_HTML5, "ISO-8859-1" ) ;
  $mydata[ $PERS ]->have = 1;
}

$query_3 = "SELECT * FROM " . $MainDB . "_DANS";
$result_3 = mysqli_query($emperator,$query_3);
if($result_3) while( $row_3 = mysqli_fetch_array($result_3) )
{
  $PERS = $row_3['dans_pers'];
  if( ! array_key_exists( $PERS , $mydata ) ) continue;
  $mydata[ $PERS ]->ud = $row_3['dans_ud'];
  $mydata[ $PERS ]->lr = $row_3['dans_lr'];
  $mydata[ $PERS ]->have += 1;
}

$query_4 = "SELECT * FROM " . $MainDB . "_ANS WHERE ans_puls=" . $PULS;
$result_4 = mysqli_query($emperator,$query_4);
if($result_4) while( $row_4 = mysqli_fetch_array($result_4) )
{
  $PERS = $row_4['ans_pers'];
  if( ! array_key_exists( $PERS , $mydata ) ) continue;
  if( $row_4['ans_qgroup'] == 1 )
  {
    $mydata[ $PERS ]->u1 = $row_4['ans_value'];
    $mydata[ $PERS ]->have += 1;
  }
  if( $row_4['ans_qgroup'] == 2 )
  {
    $mydata[ $PERS ]->u2 = $row_4['ans_value'];
    $mydata[ $PERS ]->have += 1;
  }
}

echo "\n<script>\n";
echo "data = [\n";

foreach($mydata as $pers => $value)
{
  if( $value->have == 4 )
  {
    echo "  { name:'" . $value->name . "', pid:" . $value->pid . ", lr:" . $value->lr . ", ud:" . $value->ud ;
    echo ", u1:" . $value->u1 . ", u2:" . $value->u2 . "},\n";
  }
}
echo "];\n</script>\n";

// data collection done, now drawing

echo <<<EOT

<img id='Disc2' src='disc2.jpg' onload='loadplus()' hidden=true />

<img id='m1' src='m1s.png' hidden=true />
<img id='m2' src='m2s.png' hidden=true />
<img id='m3' src='m3s.png' hidden=true />

<table class="plain" width='1100'><tr><td>

<canvas id="myCanvas" width="500" height="500" style="border:1px solid #000000;">
 Din browser st&ouml;der inte canvas
</canvas>

</td><td>

  <table width=500 height=500 >
    <tr width=500 height=500 >
      <td width=250 height=500 >
        <table class="plain" width=250 height=500 >
          <tr width=250 height=250 >
            <td width="250" height="250" >
              <p id='r_lf_up'> lf up </p>
            </td>
          </tr>
          <tr width=250 height=250 >
            <td width="250" height="250" >
              <p id='r_lf_dn'> lf dn </p>
            </td>
          </tr>
        </table>
      </td>
      <td width=250 height=500 >
        <p id='r_rg'> rg </p>
      </td>
    </tr>
  </table>

</td></tr></table>

<script>

function Initial( name )
{
  var outstr = "";
  var i=0;
  var c='';
  while (i < name.length){
    c = name.charAt(i);
    if ( (c == c.toUpperCase()) && (c != c.toLowerCase()) )
    {
      outstr += c;
    }
    ++i;
  }
  return outstr;
}

var lcnt = 0;
function loadplus()
{
  ++lcnt;
  if(lcnt>=3)
    rita_disc_all();
}
var mm1 = new Image();
mm1.onload = loadplus;
mm1.src = "m1s.png";
var mm2 = new Image();
mm2.onload = loadplus;
mm2.src = "m2s.png";
var mm3 = new Image();
mm3.onload = loadplus;
mm3.src = "m3s.png";

function str_from_val( val )
{
  var str = "<img src='g";
  /**/ if(val>=90) str += '9';
  else if(val>=80) str += '8';
  else if(val>=70) str += '7';
  else if(val>=60) str += '6';
  else if(val>=50) str += '5';
  else if(val>=40) str += '4';
  else if(val>=30) str += '3';
  else if(val>=20) str += '2';
  else if(val>=10) str += '1';
  else             str += '0';
  str += ".png' width='250px' height='125px' />";
  return str;
}

function cat_from_xy( lr, ud )
{
  if( lr < 0 )
    if( ud < 0 )
      return " <img src='yellow.png' height='500px' /> ";  // entusiast
    else
      return " <img src='red.png' height='500px' /> ";     // ledare
  else
    if( ud < 0 )
      return " <img src='green.png' height='500px' /> ";   // v�n
    else
      return " <img src='blue.png' height='500px' /> ";    // forskare
}

var last = -2;

function print_found(found)
{
  if (found==last) return;
  last = found;

  var para_lf_up = document.getElementById( "r_lf_up" );
  var para_lf_dn = document.getElementById( "r_lf_dn" );
  var para_rg    = document.getElementById( "r_rg"    );

  para_lf_dn.innerHTML =
    "<p align='center'> M&aring;luppfyllnad Elitteam <br> Namn / Gruppen </p> <br>" +
    " <img src='wheel.png' height='250px' width='250px' /> "; 

  if(found<0)
  {
    para_lf_up.innerHTML = "<p align='center'>  Bidrag till gruppen <br> Genomsnitt i gruppen</p>";
    para_rg.innerHTML = " <p align='center'> <img src='MOW.png' height='500px' /> </p> ";
    var sum = 0, ii, nn = data.length;
    for( ii in data )
      sum += data[ii].u2;
    var avg = (1.0 * sum) / (1.0 * nn);
    var str = str_from_val(avg);
    para_lf_up.innerHTML += " <br> <p align='center'>" + str + "</p>"; 
    return;
  }

  var nam = data[found].name;
  para_lf_up.innerHTML = "<p align='center'> Bidrag till gruppen <br> " + nam + " </p>";
  para_rg.innerHTML = "<p align='center'> " + cat_from_xy(data[found].lr, data[found].ud) + " </p>";
  var str = str_from_val(data[found].u2);
  para_lf_up.innerHTML += " <br> <p align='center'>" + str + "</p>";

}

function onmousemove(e)
{
  // important: correct mouse position:
  var rect = this.getBoundingClientRect(),
      x = e.clientX - rect.left,
      y = e.clientY - rect.top;

  var c=document.getElementById("myCanvas");
  var ctx=c.getContext("2d");

  var i, found = -1;
  for (i in data)
  {
    lx = xyscale(data[i].lr);
    ly = xyscale(data[i].ud);
    dist = Math.hypot( x - lx , y - ly );
    if(dist<15)
    {
      found = i;
    }
  }

  print_found(found);
}


function rita_disc_base()
{
  var c=document.getElementById("myCanvas");
  c.onmousemove = onmousemove;

  var ctx=c.getContext("2d");
  ctx.fillStyle="#fff";
  var d2=document.getElementById("Disc2");
  ctx.fillRect(0,0,500,500);
  ctx.drawImage(d2,0,0);
}

function rita_disc_1(lr, ud, val, str )
{
  var c=document.getElementById("myCanvas");
  var ctx=c.getContext("2d"); ctx.fillStyle="#fff";
  var gubb;
  if(val>66)
    gubb=mm3;
  else if(val>33)
    gubb=mm2;
  else
    gubb=mm1;
  var xp = xyscale(lr), yp = xyscale(ud);
  ctx.drawImage(gubb,xp-16,yp-16); // image is 32x32
  var fsz = 16;
  ctx.font = "" + fsz + "px Sans-serif Bold";
  var w = ctx.measureText(str).width;
  var h = 16;
  var xx = xp - (w/2);
  var yy = yp + (h/2) + fsz;

  ctx.strokeStyle = 'black';
  ctx.lineWidth = 3;
  ctx.strokeText(str, xx, yy);
  ctx.fillStyle = 'white';
  ctx.fillText(str, xx, yy);

}

function rita_disc_all()
{
  rita_disc_base();
  var xx;
  for (xx in data)
  {
    rita_disc_1( data[xx].lr, data[xx].ud, data[xx].u1, Initial(data[xx].name) );
  }
}


</script><br />

<img onload="rita_disc_all()" src="sq.png" /> <br />

<script>
  rita_disc_all();
  print_found(-1);
</script>

<br><br>

EOT;

	echo "<br><center>";
	echo "<button onclick=\"Goto('disp_user.php?pid=";
	echo $_GET['pid'] . "&puls=" . $_GET['puls'] . "')\"> Tillbaka </button>  \n";




mysqli_close($emperator);

include('wrapper_after.php');

?>

