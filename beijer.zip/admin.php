
<?php

$TITLE="ElitTeam";

include('wrapper_before.php');

include('connect.inc');
include('ftg.inc');

echo "<center><table style='width:70%'><tr><td>\n";

echo "<br><br>\n";

// --------------------------------------------------------

$dir    = '.';
$files1 = scandir($dir);
$files2 = scandir($dir, 1);

print_r($files1);
print_r($files2);

// --------------------------------------------------------


echo "<table class='pretty'>\n";

echo "<caption> Personer </caption>\n";
echo "<tr> <th> Namn </th> <th> Avdelning </th> <th> Titel </th> <th> Kategorier </th> <th> Svarat </th> <th> Logga in </th> <th> Personsida </th> <th> Rensa </th> </tr> \n";


$query_post = "SELECT * FROM " . $MainDB . "_PERS";
$result = mysqli_query($emperator, $query_post);
while ($row = mysqli_fetch_array($result))
{
	$PID = $row['pers_id'];
	
	echo "<tr class='pretty'>";
	
	$str = htmlentities( $row['pers_fname'] . " " . $row['pers_ename'], ENT_COMPAT | ENT_HTML5, "UTF-8" ) ;
	
	echo "<td>" . $str . "</td>";
	echo "<td>" . $row['pers_avd'] . "</td>";
	echo "<td>" . $row['pers_tit'] . "</td>";

	$KAT = 0;
	$ANS = 0;

	$query_post_2 = "SELECT * FROM " . $MainDB . "_PKAT WHERE pkat_pers='" . $PID . "'";
	$result_2 = mysqli_query($emperator, $query_post_2);
	if ($result_2) while ($row_2 = mysqli_fetch_array($result_2))
	{
		$KAT += 1;
		if ($row_2['pkat_qdone'])
			$ANS += 1;
	}

	echo "<td>" . $KAT . "</td>";
	echo "<td>" . $ANS . "</td>";

	echo "<td> <a href='survey.php?email=" . $row['pers_email'] . "&puls=" . $LATEST_PULS . "'> Logga in </a> </td> \n";

	echo "<td> <a href='disp_user.php?pid=" . $PID . "&puls=1'> Personsida </a> </td> \n";

	echo "<td> <a href='rensa.php?pid=" . $PID . "'> Rensa </a> </td> \n";
	
	echo "</tr>";
}

echo "</table>\n";

// --------------------------------------------------------

echo "</td></tr>\n";

echo "</td></tr></table></center>\n";



?>
