
<?php

$TITLE="ElitTeam";

include('wrapper_before.php');

include('connect.inc');
include('ftg.inc');

// max 1 : 20 * 
// max 2 : 30 * 5 = 150

$PULS = $_GET['puls'];
$PID = $_GET['id'];

$A1 = 0;
$A2 = 0;

$S1 = true;
$S2 = true;

if (isset($_GET['s']))
{
	if ($_GET['s'] == '1')
	{
		$S2 = false;
	}
	else if ($_GET['s'] == '2')
	{
		$S1 = false;
	}
}

$query = "SELECT * FROM " . $MainDB . "_ANS " . "WHERE ans_puls='" . $PULS . "' AND ans_pers='" . $PID . "'";
if($result = mysqli_query( $emperator, $query ))
{
	while($row = mysqli_fetch_array($result))
	{
		if( $row['ans_qgroup'] == 1 ) $A1 = $row['ans_value'];
		if( $row['ans_qgroup'] == 2 ) $A2 = $row['ans_value'];
	}
}

$FN1 = "g" . intval($A1/10) . ".png";
$FN2 = "g" . intval($A2/10) . ".png";

if ($S1)
{
	echo "<table><tr><td>resultat m&auml;tning ett </td></tr></table><br>";
	echo "<img src='" . $FN1 . "' width='60%' /> <br><br>";
}

if ($S2)
{
	echo "<table><tr><td>resultat m&auml;tning tv&aring; </td></tr></table><br>";
	echo "<img src='" . $FN2 . "' width='60%' /> <br><br>";
}

	echo "<br><center>";
	echo "<button onclick=\"Goto('disp_user.php?pid=";
	echo $_GET['id'] . "&puls=" . $_GET['puls'] . "')\"> Tillbaka </button>  \n";
	echo "<br></center>\n";




mysqli_close($emperator);

include('wrapper_after.php');

?>

