
<?php

$TITLE="ElitTeam";

include('wrapper_before.php');

include('connect.inc');
include('ftg.inc');

echo "<center><table style='width:70%'><tr><td>\n";

echo "<br><br>\n";

// --------------------------------------------------------

echo "<table class='pretty'>\n";

echo "<caption> Personer </caption>\n";
echo "<tr> <th> Namn </th> <th> Avdelning </th> <th> Titel </th> <th> Kategorier </th> <th> Svarat </th> <th> Utv&auml;rderat </th> </tr> \n";


$query_post = "SELECT * FROM " . $MainDB . "_PERS";
$result = mysqli_query($emperator, $query_post);
while ($row = mysqli_fetch_array($result))
{
	$PID = $row['pers_id'];
	
	echo "<tr class='pretty'>";
	
	$str = htmlentities( $row['pers_fname'] . " " . $row['pers_ename'], ENT_COMPAT | ENT_HTML5, "UTF-8" ) ;
	
	echo "<td>" . $str . "</td>";
	echo "<td>" . $row['pers_avd'] . "</td>";
	echo "<td>" . $row['pers_tit'] . "</td>";

	$KAT = 0;
	$ANS = 0;
	$UTV = 0;

	$query_post_2 = "SELECT * FROM " . $MainDB . "_PKAT WHERE pkat_pers='" . $PID . "'";
	$result_2 = mysqli_query($emperator, $query_post_2);
	if ($result_2) while ($row_2 = mysqli_fetch_array($result_2))
	{
		$KAT += 1;
		if ($row_2['pkat_qdone'])
			$ANS += 1;
		if ($row_2['pkat_utvdone'])
			$UTV += 1;
	}

	echo "<td>" . $KAT . "</td>";
	echo "<td>" . $ANS . "</td>";

	$LNK = "<a href='c_eval.php?pid=" . $PID . "'> Utv&auml;rdera </a>";

	echo "<td>";
	if ( ($KAT==0) || ($KAT != $ANS))
	{
		echo "Ej klar med svar";
	}
	else if ($UTV==0)
	{
		echo $LNK;
	}
	else if ($UTV==$KAT)
	{
		echo "Klar";
	}
	else
	{
		echo $UTV . " / " . $KAT . " " . $LNK;
	}
	echo "</td>";
	echo "</tr>";
}

echo "</table>\n";

// --------------------------------------------------------


echo "</td></tr></table></center>\n";



?>
