
<?php

include('connect.inc');
include('ftg.inc');

$TITLE = "Disc resultat";
include('wrapper_before.php');

$LR = 0;
$UN = 0;

$query = "SELECT * FROM ET_DANS WHERE dans_pers='" . $_GET['id'] . "'";

$result = mysqli_query( $emperator, $query );
if($row = mysqli_fetch_array($result))
{
	$LR = $row['dans_lr'];
	$UN = $row['dans_ud'];
}

include 'disc.inc';

echo "<br>";

echo "<br><center>";
echo "<button onclick=\"Goto('disp_user.php?pid=" . $_GET['id'] . "')\"> Tillbaka </button>  \n";
echo "<br></center>\n";


mysqli_close($emperator);

include('wrapper_after.php');

?>


