
<?php

$TITLE="ElitTeam";

include('wrapper_before.php');

include('connect.inc');
include('ftg.inc');

$PID = $_GET['pid'];
$PULS = $_GET['puls'];

$query_post = "SELECT * FROM " . $MainDB . "_PERS WHERE pers_id=" . $PID;

echo "<center><table style='width:70%'><tr><td>\n";

// displaya personuppgifter

 echo "<h1><b>Beijermedarberare</b></h1><br>\n";
 
 $result0 = mysqli_query($emperator,$query_post);
 if( $row_0 = mysqli_fetch_array($result0) )
 {
 	$str = htmlentities( $row_0['pers_fname'] . " " . $row_0['pers_ename'], ENT_COMPAT | ENT_HTML5, "ISO-8859-1" ) ;
 	echo $str . "<br><br>\n";
	echo $row_0['pers_avd'] . "<br\n";
	echo $row_0['pers_tit'] . "<br\n";
 } else {
 	echo "&lt;no user&gt;<br>\n";
 }

// function for knapp i ruta

function BLOCK($TIT, $BTN)
{
	echo "<br><center>";
	echo "<div id='disc' style='width:350px;'>\n";
	echo "   <fieldset>\n";
	echo "      <legend style='color:black;font-weight:900;'>" . $TIT . "</legend>\n";
	echo "      <table class='plain'>\n";
	echo "         " . $BTN . "\n";
	echo "      </table>\n";
	echo "   </fieldset>\n";
	echo "</div>\n";
	echo "<br></center>";
}

include('make_pkat.inc');

if ($PKSZ == 0)
{
	include('disp_user_text_A.inc');
	echo "<br><center>\n";
	include('query_allkat.inc');
}
else if ($PKDONE < $PKSZ)
{
	include('disp_user_text_B.inc');
	echo "<br><center>\n";
	include('select_nextkat.inc');
}
else if ($PKSZ2 == 0)
{
	include('disp_user_text_C.inc');
	echo "<br><center>\n";
	include('select_morekat.inc');
}
else if ($PKDONE2 < $PKSZ2)
{
	include('disp_user_text_D.inc');
	echo "<br><center>\n";
	include('execute_morekat.inc');
}
else
{
	include('disp_user_text_E.inc');
	echo "<br><center>\n";
	//echo "DONE!!!<br>\n";
}

echo "</center>\n";


echo "</td></tr></table></center>\n";

mysqli_close($emperator);

include('wrapper_after.php');

?>

