<?php

$TITLE="ElitTeam M&auml;tning";

include('wrapper_before.php');

include('connect.inc');
include('ftg.inc');


$fraga = 0;

echo '&nbsp;<br>' . "\n" ;

function sel123($id)
{
	echo '&nbsp;&nbsp;<input type="radio" id="' . $id . '" name="' . $id . '" value="1">Inget<br>                  </input>' . "\n" ;
	echo '&nbsp;&nbsp;<input type="radio" id="' . $id . '" name="' . $id . '" value="2">Lite<br>                   </input>' . "\n" ;
	echo '&nbsp;&nbsp;<input type="radio" id="' . $id . '" name="' . $id . '" value="3">Mellan<br>                 </input>' . "\n" ;
	echo '&nbsp;&nbsp;<input type="radio" id="' . $id . '" name="' . $id . '" value="4">Mycket<br>                 </input>' . "\n" ;
	echo '&nbsp;&nbsp;<input type="radio" id="' . $id . '" name="' . $id . '" value="5">Helt och h&aring;llet<br>  </input>' . "\n" ;
}

function iterall($res)
{
	global $fraga;

	echo "<table><tr><td>\n";

	while($row = mysqli_fetch_array($res))
	{
		if($row['query_sns']) {
			echo "<hr><br><br>";
		}
		$fraga += 1;
		$str = htmlentities( $row['query_title'] . $row['query_text'], ENT_COMPAT | ENT_HTML5, "ISO-8859-1" ) ;
		$str = "<b>" . $str . "</b>" ;
		echo $str . '<br>' . "\n" ;
		sel123( $fraga . "_q" );
		echo "<br><br>\n" ;
	}

	echo "</td></tr></table>\n";

}

function grp($nam)
{
	echo "<hr>";
	echo '<br><div class="center"> ' . $nam . "</div><br>\n" ;
}

echo '<form name="batteri" id="batteri" >' . "\n" ;

grp("M&auml;tning ".$_GET['var']) ;

$query = "SELECT * FROM " . $MainDB . "_QUERY WHERE query_sec = '" .$_GET['var']. "'";
$result = mysqli_query($emperator,$query);
if(!$result)
	die('Error: ' . mysqli_error($emperator));
iterall($result);

echo "<hr><br>\n" ;

echo '</form>' . "\n" ;

echo '<button onclick="ET_Submit(' . $_GET['id'] . ',' . $_GET['var'] . ',' . $_GET['puls'] . ',' . $fraga . ')"> Klar </button>' . "\n" ;


mysqli_close($emperator);

include('wrapper_after.php');

?>

